'use strict'

class Agent extends Occupant {
  constructor(grid, layer, x, y) {
    super(grid, layer, x, y)
  }

  draw(context, x, y, width, height) {
    
  }
}
