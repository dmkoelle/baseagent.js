'use strict'

class SkydrawBee extends Agent {

}
